# Build Ladder

Build Ladder is an autonomous, Termux-native Android APK builder powered by AI.

## Install (Termux)
pkg install build-ladder

## Run
build-ladder

## Update
build-ladder update

## Support
Voluntary donations welcome: $yuptm
